#ifndef DEALER_HH
#define DEALER_HH

#include <vector>
#include "mainwindow.hh"

class Dealer
{

public:
    void toPickOrNotToPick();
    Dealer();


private:
    int dealer_sum_;

};

#endif // DEALER_HH
